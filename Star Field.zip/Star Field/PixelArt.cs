﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Star_Field
{
    public partial class PixelArt : Form
    {
        System.Windows.Forms.Button[] btnArray = new System.Windows.Forms.Button[13];
        int n = 0;

        int yPos = 0;
        int xPos = 0;

        Point coord = new Point(0, 0);
        int h = 25;
        int w = 25;

        int count = 0;

        public PixelArt()
        {
            InitializeComponent();
        }

        private void AddButtons()
        {
           
        }

        // Result of (Click Button) event, get the text of button 
        public void ClickButton(Object sender, System.EventArgs e)
        {
            Button btn = (Button)sender;
           //MessageBox.Show("You clicked character [" + btn.Text + "]");
        }

        private void tmrSpawn_Tick(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
        }

        private void PixelArt_Load(object sender, EventArgs e)
        {
            Spawn.Start();
            
        }

        private void Spawn_Tick(object sender, EventArgs e)
        {
           
            count++;
            System.Windows.Forms.Button[] btnArray = new System.Windows.Forms.Button[13];
            for (int i = 0; i < 13; i++)
            {
                btnArray[i] = new System.Windows.Forms.Button();
            }
            


            while (n < 13)
            {
                btnArray[n].Tag = n + 1;
                btnArray[n].Width = 25;
                btnArray[n].Height = 25;
                if (n == 13)
                {
                    xPos = 0;
                    yPos = 20;
                }
                btnArray[n].Left = xPos;
                btnArray[n].Top = yPos;

                this.Controls.Add(btnArray[n]);
                xPos = xPos + btnArray[n].Width;


                btnArray[n].Click += new System.EventHandler(ClickButton);
                btnArray[n].MouseMove += new MouseEventHandler(Mousemove);
                n++;
            }
            if(xPos >= 500)
            {
                xPos = -25;
                yPos+=25;
                xPos += 25;
            }

            if(count == 20)
            {
                Spawn.Stop();
            }
            
        }

        private void Mousemove(object sender, MouseEventArgs e)
        {
            btnArray[n].BackColor = Color.Red;
        }
    }
}

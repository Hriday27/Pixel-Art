﻿namespace Star_Field
{
    partial class Grid
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Rows = new System.Windows.Forms.Timer(this.components);
            this.Coloumns = new System.Windows.Forms.Timer(this.components);
            this.pnlTool = new System.Windows.Forms.Panel();
            this.btnColor = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.cdFill = new System.Windows.Forms.ColorDialog();
            this.cdBoundary = new System.Windows.Forms.ColorDialog();
            this.pnlTool.SuspendLayout();
            this.SuspendLayout();
            // 
            // Rows
            // 
            this.Rows.Tick += new System.EventHandler(this.Rows_Tick);
            // 
            // Coloumns
            // 
            this.Coloumns.Tick += new System.EventHandler(this.Coloumns_Tick);
            // 
            // pnlTool
            // 
            this.pnlTool.Controls.Add(this.button1);
            this.pnlTool.Controls.Add(this.btnColor);
            this.pnlTool.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlTool.Location = new System.Drawing.Point(0, 0);
            this.pnlTool.Name = "pnlTool";
            this.pnlTool.Size = new System.Drawing.Size(150, 577);
            this.pnlTool.TabIndex = 0;
            // 
            // btnColor
            // 
            this.btnColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnColor.Location = new System.Drawing.Point(0, 0);
            this.btnColor.Name = "btnColor";
            this.btnColor.Size = new System.Drawing.Size(150, 58);
            this.btnColor.TabIndex = 0;
            this.btnColor.Text = "Select Color";
            this.btnColor.UseVisualStyleBackColor = true;
            this.btnColor.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(0, 57);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 58);
            this.button1.TabIndex = 1;
            this.button1.Text = "Boundary Color";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Grid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(826, 577);
            this.Controls.Add(this.pnlTool);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Grid";
            this.Text = "Grid";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Grid_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Grid_KeyPress);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Grid_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Grid_MouseMove);
            this.pnlTool.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer Rows;
        private System.Windows.Forms.Timer Coloumns;
        private System.Windows.Forms.Panel pnlTool;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnColor;
        private System.Windows.Forms.ColorDialog cdFill;
        private System.Windows.Forms.ColorDialog cdBoundary;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Star_Field
{
    public partial class Grid : Form
    {
        SolidBrush brush = new SolidBrush(Color.Red);

        bool startdraw = false;

        //Points
        Point a;
        Point b;
        Point c;
        Point d;

        Pen p = new Pen(Color.White);

        int spacing = 25;

        //Rows
        Point r1 = new Point(0, 25);
        Point r2 = new Point(500, 25);

        //Coloumns 
        Point c1 = new Point(25, 0);
        Point c2 = new Point(25, 500);

        public Grid()
        {
            InitializeComponent();
        }

        private void Rows_Tick(object sender, EventArgs e)
        {
            r2.X = this.Width;
            Graphics g = CreateGraphics();
            g.DrawLine(p, r1, r2);
            r1.Y += spacing;
            r2.Y += spacing;

            if (r1.Y >= 2000)
            {
                Rows.Stop();
            }
        }

        private void Coloumns_Tick(object sender, EventArgs e)
        {
            c2.Y = this.Height;
            Graphics g = CreateGraphics();
            g.DrawLine(p, c1, c2);
            c1.X += spacing;
            c2.X += spacing;

            if(c1.X >= 20000)
            {
                Coloumns.Stop();
            }
        }

        private void Grid_Load(object sender, EventArgs e)
        {
            Rows.Start();
            Coloumns.Start();
        }

        void DrawRectangle(int x, int y)
        {
            Graphics g = CreateGraphics();
            Pen p = new Pen(Color.Red);
            SolidBrush brush = new SolidBrush(Color.Red);
            Rectangle rect = new Rectangle(x, y, 25,25);
            g.DrawRectangle(p, rect);
            g.FillRectangle(brush, rect);
        }

        private void Grid_MouseMove(object sender, MouseEventArgs e)
        {
            if (startdraw)
            {
                Graphics g = CreateGraphics();
                //Pen p = new Pen(brush.Color);


                int quotientx = e.X / 25;
                int quotienty = e.Y / 25;

                //This is for x
                a.X = quotientx * 25;
                b.X = quotientx * 25 + 25;
                c.X = quotientx * 25;
                d.X = quotientx * 25 + 25;

                //This is for y
                a.Y = quotienty * 25;
                b.Y = quotienty * 25;
                c.Y = quotienty * 25 + 25;
                d.Y = quotienty * 25 + 25;

                Rectangle rect = new Rectangle(a.X, a.Y, 25, 25);
                g.DrawRectangle(p, rect);
                g.FillRectangle(brush, rect);
            }
            else
            {

            }
        }

        private void Grid_MouseDown(object sender, MouseEventArgs e)
        {
            startdraw = true;
        }

        private void Grid_KeyPress(object sender, KeyPressEventArgs e)
        {
            startdraw = false;
        }

        private void btnColor_Click(object sender, EventArgs e)
        {
            cdFill.ShowDialog();
            brush.Color = cdFill.Color;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cdBoundary.ShowDialog();
            p.Color = cdBoundary.Color;
        }
    }
}
